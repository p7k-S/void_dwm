#!/bin/sh
# picom --vsync --backend glx --inactive-dim 0.2 --no-fading-openclose --inactive-dim-fixed --config /dev/null --focus-exclude "x = 0 && y = 0 && override_redirect = true" &
# pgrep copyq || copyq --start-server && copyq hide
# flameshot &

setxkbmap us,ru -option 'grp:alt_shift_toggle' -option ctrl:swapcaps &
xset r rate 300 30 &
# unclutter -idle 2 &
# dwmblocks &
# clipmenud &
# picom &
# feh --no-fehbg --bg-scale /home/pavel/Pictures/Wallpapers/zdanie_minimalizm_chb_132403_1920x1080.jpg
# nm-applet &
# ~/.config/suckless/dwmblocks/scripts/brightness_warn_dec_15.sh &
# ~/.tmux/scrpad.sh &
# twmnd &

# telegram-desktop &
# qutebrowser &
# thorium.AppImage &


while true; do 
    dwm 2> ~/.config/logs/dwm.log
done
