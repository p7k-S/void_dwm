#!/bin/sh

if pgrep -x dwmblocks > /dev/null; then
    killall dwmblocks
fi

if [ $# -eq 1 ]; then  # проверка кол-ва аргум
    str=$1
    xsetroot -name "^b#ff0000^^c#000000^"$(str)
    sleep 2
elif ! pgrep -x dwmblocks > /dev/null; then
    dwmblocks
fi
