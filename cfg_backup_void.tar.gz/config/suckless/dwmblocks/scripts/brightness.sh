#!/bin/sh

# # for dwmblocks
br=$(echo "$(cat /sys/class/backlight/*/brightness)" | tr -d '-')
# res=$(( (br) * 100 / 255 ))
#
# echo " ^b#171713^  $res"

# for notif
if [ "$br" -eq 0 ] || [ "$br" -eq 255 ]; then
    killall dwmblocks
    xsetroot -name "^c#d79921^   ##########___LIMIT_BRIGHTNESS___############"
    sleep 2
    if ! pgrep -x dwmblocks > /dev/null; then
        dwmblocks
    fi
fi






# pkill -RTMIN+11 dwmblocks

# msgid="3378455"
# dunstify -a "changebrightness" -u low -r "$msgid" \
# 	-h int:value:"$res" "brightness: ${res}%" -t 300

# notify-send "Backlight is $(printf $(res))"
