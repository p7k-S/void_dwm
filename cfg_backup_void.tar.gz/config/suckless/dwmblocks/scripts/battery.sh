#!/bin/sh

battery_info=$(acpi)
capacity=$(cat /sys/class/power_supply/BAT1/capacity)

if echo "$battery_info" | grep -q "Charging"; then
    echo "^b#111111^^c#b8bb26^  $(cat /sys/class/power_supply/BAT1/capacity)%^d^"
else
    if [ "$capacity" -gt 75 ]; then
        echo "^b#111111^  $(cat /sys/class/power_supply/BAT1/capacity)%"
    elif [ "$capacity" -gt 50 ]; then
        echo "^b#111111^  $(cat /sys/class/power_supply/BAT1/capacity)%"
    elif [ "$capacity" -gt 25 ]; then
        echo "^b#111111^  $(cat /sys/class/power_supply/BAT1/capacity)%"
    elif [ "$capacity" -gt 10 ]; then
        echo "^b#111111^  $(cat /sys/class/power_supply/BAT1/capacity)%"
    else
        echo "^b#111111^ ^c#fb4934^ $(cat /sys/class/power_supply/BAT1/capacity)%^d^"
    fi
fi
