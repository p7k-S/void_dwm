#!/bin/sh

echo "$(date '+%b-%a %Y-%m-%d')"
