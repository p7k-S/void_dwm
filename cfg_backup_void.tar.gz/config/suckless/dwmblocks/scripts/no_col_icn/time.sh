#!/bin/sh

echo "$(date '+%H:%M:%S') "
