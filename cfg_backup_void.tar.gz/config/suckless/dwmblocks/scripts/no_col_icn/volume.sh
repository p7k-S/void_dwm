#!/bin/sh

echo "Vol:$(pactl get-sink-volume @DEFAULT_SINK@ |  awk '{print $5}')"
