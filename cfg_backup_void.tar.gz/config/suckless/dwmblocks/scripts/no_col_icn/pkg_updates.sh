#!/bin/sh

echo "pkg:$(xbps-install --memory-sync --dry-run --update | grep -Fe update -e install | wc -l)"
