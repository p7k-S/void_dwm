#!/bin/sh

br=$(echo "$(cat /sys/class/backlight/*/brightness)" | tr -d '-')

if [ "$br" -eq 0 ] || [ "$br" -eq 255 ]; then
    killall dwmblocks
    xsetroot -name " LIMIT OF BRIGHTNESS                                                                                                 "
    sleep 2
    if ! pgrep -x dwmblocks > /dev/null; then
        dwmblocks
    fi
fi
