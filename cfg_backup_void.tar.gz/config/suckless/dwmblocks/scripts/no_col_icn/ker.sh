#!/bin/sh

echo " ker:$(uname -r)"
