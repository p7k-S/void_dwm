#!/bin/sh

echo "AC:$(cat /sys/class/power_supply/BAT1/capacity)%"
