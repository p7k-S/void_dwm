#!/bin/sh
# ^b#40421d^ ^c#ffffff^
echo " ^d^^b#232316^ 󱑆 $(date '+%H:%M:%S') "
