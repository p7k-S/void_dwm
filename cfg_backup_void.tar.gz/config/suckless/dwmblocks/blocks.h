//Modify this file to change what commands output to your statusbar, and recompile using the make command.
static const Block blocks[] = {
	/*Icon*/            	            /*Command*/	                  /*Update Interval*/ 	/*Update Signal*/
	// {"",    "~/.config/suckless/dwmblocks/scripts/brightness.sh",	0,		5},

	{"",    "~/.config/suckless/dwmblocks/scripts/no_col_icn/ker.sh",           0,	    0},
	{"",    "~/.config/suckless/dwmblocks/scripts/no_col_icn/pkg_updates.sh",  300,	    13},
	{"",    "~/.config/suckless/dwmblocks/scripts/no_col_icn/battery.sh",      30,		9},
	{"",    "~/.config/suckless/dwmblocks/scripts/no_col_icn/cpu.sh",	        10,		12},
	{"",    "~/.config/suckless/dwmblocks/scripts/no_col_icn/mem.sh",	        10,		14},
    {"",	"~/.config/suckless/dwmblocks/scripts/no_col_icn/keyboard_lay.sh",   0,	    2},
    {"",	"~/.config/suckless/dwmblocks/scripts/no_col_icn/mic.sh",	        0,      3},
	{"",	"~/.config/suckless/dwmblocks/scripts/no_col_icn/volume.sh",        0,      10},
	{"",    "~/.config/suckless/dwmblocks/scripts/no_col_icn/bluetooth.sh",	    1,    	0}, //batery ??? нужно каждую сек
	{"",	"~/.config/suckless/dwmblocks/scripts/no_col_icn/net.sh",	        1,    	0},
	{"",    "~/.config/suckless/dwmblocks/scripts/no_col_icn/date.sh",		    1,      0},
	{"",    "~/.config/suckless/dwmblocks/scripts/no_col_icn/time.sh",		    1,      0},
};

//sets delimiter between status commands. NULL character ('\0') means no delimiter.
static char delim[] = "  ";
static unsigned int delimLen = 5;
