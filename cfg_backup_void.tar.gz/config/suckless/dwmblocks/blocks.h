//Modify this file to change what commands output to your statusbar, and recompile using the make command.
static const Block blocks[] = {
	/*Icon*/            	            /*Command*/	                  /*Update Interval*/ 	/*Update Signal*/

	// {" ",   "uname -r",	0,   15},
	// {" Pkg:",   "xbps-install -SMun | wc -l",	3600,   8},
	// {"",    "~/.config/suckless/dwmblocks/scripts/brightness.sh",	0,		5},
	{"",    "~/.config/suckless/dwmblocks/scripts/battery.sh",      90,		9},
	{"",    "~/.config/suckless/dwmblocks/scripts/sb-cpu",	        10,		12},
	{"",    "~/.config/suckless/dwmblocks/scripts/sb-mem",	        10,		14},
    {"",	"~/.config/suckless/dwmblocks/scripts/sb-layout",	    0,	    2},
    {"",	"~/.config/suckless/dwmblocks/scripts/sb-mic",	        0,      3},
	{"",	"~/.config/suckless/dwmblocks/scripts/sb-vol",	        0,     10},
	{"",    "~/.config/suckless/dwmblocks/scripts/sb-bluetooth",	1,    	0}, //batery ????? нужно каждую сек
	{"",	"~/.config/suckless/dwmblocks/scripts/sb-wlan",	        1,    	0},
	{"",	"~/.config/suckless/dwmblocks/scripts/sb-luke",	        1,    	0},
	{"",    "~/.config/suckless/dwmblocks/scripts/date.sh",		    1,      0},
	{"",    "~/.config/suckless/dwmblocks/scripts/time.sh",		    1,      0},
};

//sets delimiter between status commands. NULL character ('\0') means no delimiter.
static char delim[] = "";
static unsigned int delimLen = 5;
