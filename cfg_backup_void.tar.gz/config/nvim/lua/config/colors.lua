--require('kanagawa').setup({
--    commentStyle = { italic = true },
--    keywordStyle = { italic = false},
--})

local function set_colors(color)
    -- color = color or "rose-pine-moon"
    -- color = color or "pablo"
    -- color = color or "retrobox"
    color = color or "gruvbox"
    -- color = color or "default"
    -- color = color or "bamboo"
    -- color = color or "gruvbox-material"
    -- color = color or "kanagawa-dragon"
    -- color = color or "quiet"
    -- color = color or "habamax"
    -- color = color or "lunaperche"
    -- color = color or "vim"
    -- color = color or "shine"
    vim.cmd.colorscheme(color)

    -- vim.api.nvim_set_hl(0, "Normal", { bg = "#1a1b1c" })
    -- vim.api.nvim_set_hl(0, "NormalFloat", { bg = "#1a1b1c" })

    -- trancparancy
    vim.api.nvim_set_hl(0, "Normal", { bg = "none" })
    vim.api.nvim_set_hl(0, "NormalFloat", { bg = "none" })
end

set_colors()
