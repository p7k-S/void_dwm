#!/bin/bash

kill $(pidof sh | awk '{print $1}')
