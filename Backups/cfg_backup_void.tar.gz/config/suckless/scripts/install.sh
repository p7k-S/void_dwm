#!/bin/sh

echo "link startup.sh to .xinitrc"
ln -sf ~/.config/suckless/scripts/startup_dwm.sh ~/.xinitrc 
echo ""
echo "link all scripts to /usr/local/bin"
sudo ln -sf ~/.config/suckless/scripts/* /usr/local/bin/ 
echo ""

cd ~/.config/suckless
echo "dmenu:"
echo ""
cd dmenu && sudo rm config.h && sudo make clean install

echo ""
echo "st-tmux:"
echo ""
cd ../st-tmux && sudo rm config.h && sudo make clean install
sudo mv /usr/local/bin/st /usr/local/bin/st-tmux

echo ""
echo "st:"
echo ""
cd ../st && sudo rm config.h && sudo make clean install

echo ""
echo "clipmenu:"
echo ""
cd ../clipmenu && sudo make install

echo ""
echo "dwm:"
echo ""
cd ../dwm && sudo rm config.h && sudo make clean install

echo ""
echo "slock:"
echo ""
cd ../slock && sudo rm config.h && sudo make clean install

echo ""
echo "dwmblocks:"
echo ""
cd ../dwmblocks && sudo rm blocks.h && sudo make clean install
