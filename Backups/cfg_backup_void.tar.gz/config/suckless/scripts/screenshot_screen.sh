#!/bin/sh

scrot ~/Pictures/Screenshots/%y-%m-%d_%h-%m-%s_$wx$h.png && xsetroot -name ' screenshot saved in ~/Pictures/Screenshots '
