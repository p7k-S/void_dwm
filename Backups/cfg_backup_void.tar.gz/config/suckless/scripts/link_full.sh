#!/bin/sh

echo "link all scripts to /usr/local/bin"
sudo ln -sf ~/.config/suckless/scripts/* /usr/local/bin/ 
echo ""
