#!/bin/sh

cd && xbps-query -lm | sed 's/-[^-]*$//' > Backups/installed_pkgs &&  tar czf cfg_backup_void.tar.gz \
    ~/Backups/installed_pkgs \
    .config/zathura/* \
    .config/mimeapps.list \
    .config/user-dirs.dirs \
    .config/suckless/* \
    .config/wayland/* \
    .config/nvim \
    .config/picom \
    .aliasrc \
    .zshrc \
    .Xresources \
    .tmux.conf \
    /etc/X11/xorg.conf.d/* \
    /etc/doas.conf \
    && mv cfg_backup_void.tar.gz Backups && cd -


    # .config/minimal/suckless.tar.gz \
    # /etc/pacman.d/mirrorlist_sorted.backup \
    
    # .fonts/JetBrains/* \
    # /usr/share/xsessions/dwm.desktop \
    
    # .xinitrc \
    # /etc/doas.conf \
    # /etc/pacman.conf \
    # /etc/pacman.d/mirrorlist \
    # /etc/pacman.d/mirrorlist_sorted.backup \
    # /etc/X11/xorg.conf.d/* \
    # .gitstatus/* \
