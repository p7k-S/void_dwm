#!/bin/sh

echo "$(uname -r)"
