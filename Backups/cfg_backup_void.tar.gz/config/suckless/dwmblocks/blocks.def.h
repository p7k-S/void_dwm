//Modify this file to change what commands output to your statusbar, and recompile using the make command.
static const Block blocks[] = {
	/*Icon*/            	            /*Command*/	                  /*Update Interval*/ 	/*Update Signal*/
	// {" ",    "br.sh",	0,		5},
	// {"",    "xbps-install -Sun | wc -l",                                         300,	    13},
	// {"",    "uptime.sh",        60,	    0},
	// {"",    "ker.sh",           0,	    0},
	{" ",    "updates.sh",  300,	    13},
	{"",    "battery.sh",      3,		9},
	// {"",    "disks.sh",	60,		0},
	{"",    "cpu.sh",	        10,		12},
	{"",    "mem.sh",	        10,		14},
    {"",	"keyboard_lay.sh",   0,	    2},
    {"",	"mic.sh",	        3,      3},
	{"",	"volume.sh",        3,      10},
	{"",    "bluetooth.sh",	    1,    	0}, //??? нужно каждую сек
	{"",	"net.sh",	        1,    	0},
	{"",    "date.sh",		    1,      0},
	{"",    "time.sh",		    1,      0},
};

//sets delimiter between status commands. NULL character ('\0') means no delimiter.
// static char delim[] = " ¦│░⁞║";
static char delim[] = " | ";
static unsigned int delimLen = 5;
