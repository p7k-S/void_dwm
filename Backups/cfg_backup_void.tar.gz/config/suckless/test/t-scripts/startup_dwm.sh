#!/bin/sh

pipewire &
setxkbmap us,ru -option 'grp:alt_shift_toggle' -option ctrl:swapcaps &
xset r rate 300 30 &
unclutter -idle 2 &
clipmenud &
scrpad.sh &
dwmblocks &
brightness_warn_dec_15.sh &
picom &
# feh --bg-fill ~/Pictures/Wallpapers/winXPdark.jpg &
xrdb -merge -I$HOME ~/.Xresources &

# chromium
# telegram-desktop
# st

while true; do 
    dwm 2> ~/.config/suckless/logs/dwm.log
done
